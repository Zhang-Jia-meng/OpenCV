### 动态可变的存储 PDF  P63-69
#### cv::Mat类
* cv::Mat类用于表示**任意维度**的**稠密数组**。 **稠密**的意思是这个数组的所有部分都有值存储，即使这个值是0.
* 大多数图像都是以稠密数组的形式存储的，另外还有稀疏数组spare array，稀疏数组中只存储非0的数。两者有各自的长处。
* 矩阵组成部分
    * flag元素 : 表示矩阵所含数组类型的元素；
    * dims元素 ：表示矩阵维度的元素；
    * rows,cols元素 : 表示行和列的数目的元素；（维数大于2时无效）
    * data指针 ： 指示数据真正存储位置的指针；
    * refcount元素 ： 表示该内存区域有多少个引用；
    - 数据实体data的结构被step[]描述 **有一个公式**
* 注意：
    包含在cv::Mat中的元素，可以是一个简单的数字，也可以是多个数字（多通道数组）  ？？？？？？？？？？？？？

#### 创建一个数组
* 实例化 cv::Mat 可以创建一个数组；
* create()可以申请一个内存区域；
* 一个 create 的变体是：通过指定行数和列数以及数据类型来配置二维数组的规模。
* 上面说的数组类型（type）：数据类型+通道数，格式 CV\_{8U,16S,16U,32S,32F,64F}C{1,2,3}，比如CV_32FC3表示一个三通道的32位浮点数据。
* 示例
```
cv::Mat m;

// Create data area for 3 rows and 10 columns of 3-channel 32-bit floats
m.create(3,10,CV_32FC3);

//Set the values in the 1st channel to 1.0 , the 2nd to 0.0 , and the 3rd to 1.0
m.setTo(cv::Scalar(1.0f,0.0f,1.0f));
```
等效于
```
cv::Mat m(3,10,CV_32FC3,cv::Scalar(1.0f,0.0f,1.0f));
```
* 数据与数组对象的解耦
* 代码示例（其余代码参考截图）
```
//非复制构造函数
cv::Mat;    //默认构造函数
cv::Mat(int rows,int cols,int type);
//指定类型的二维数组
cv::Mat(int rows,int cols,int type,const Scalar&s);  //指定类型的二维数组，并指定初始化值
cv::Mat(int rows,int cols,int type,void* data,size_t step = AUTO_STEP);  //指定类型的二维数组，并指定预先存储的数据
cv::Mat(cv::Size sz,int type); //指定类型的二维数组，大小由sz指定
cv::Mat(cv::Size sz,int type,const Scalar&s);
//指定类型的二维数组，并指定初始化值，大小由sz指定

//复制构造函数
cv::Mat(const Mat&mat);

//模板构造函数
cv::Mat(const cv::Vec<T,n>&vec,bool copyData = true);

//静态方法构造函数
cv::Mat::zeros(rows,cols,type);
//构造一个指定大小和类型的、值全为0的矩阵
cv::Mat::ones(rows,cols,type);
//构造一个指定大小和类型的、值全为1的矩阵
cv::Mat::eye(rows,cols,type);
//构造一个指定大小和类型的单位矩阵