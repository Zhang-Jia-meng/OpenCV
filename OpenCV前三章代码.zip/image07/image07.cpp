﻿#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <math.h>

#pragma region 重映射图像,创建波浪形效果
void wave(const cv::Mat& image, cv::Mat& result)
{
	//映射矩阵，(浮点数型cv::Mat)
	cv::Mat srcX(image.rows, image.cols, CV_32F);//描述x（列）方向的变化
	cv::Mat srcY(image.rows, image.cols, CV_32F);//描述y（行）方向的变化

	//创建映射参数
	for(int i=0;i<image.rows;i++)	//行循环
	{ 
		for (int j = 0; j < image.cols; j++) //列循环
		{
			//保持在同一列，原来第j列的像素，现在仍在第j列
			srcX.at<float>(i, j) = j;	//第j列???????如何知道这个j是给j不是给i

			//原来在第i行的像素，现在根据一个正弦曲线移动
			srcY.at<float>(i, j) = i + 3 * sin(j / 6.0);//第i行加上第j列的一个正弦函数
		}
	}

	//应用映射函数
	cv::remap(
		image,	//输入图像
		result,	//输出图像
		srcX,	//x方向映射规则
		srcY,	//y方向映射规则
		cv::INTER_LINEAR);	//插值方法
}
#pragma endregion
int main()
{
	cv::Mat image = cv::imread("boldt.jpg", 0);
	cv::imshow("1", image);

	cv::Mat result;
	wave(image, result);
	cv::imshow("2", result);
	cv::waitKey(0);
}