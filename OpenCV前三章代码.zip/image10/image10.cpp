﻿#include <iostream>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

int main()
{
	///<GrabCut分割算法>

	//读入输入图像
	cv::Mat image = cv::imread("boldt.jpg");
	if (!image.data)
		return 0;

	//显示输入图像
	cv::namedWindow("Original Image");
	cv::imshow("Original Image", image);

	//定义一个带边框的矩形，矩形外部的像素会被标记为背景
	cv::Rect rectangle(50, 25, 210, 180);

	//分割结果（四种可能的值）
	cv::Mat result;
	//模型
	cv::Mat bgModel, fgModel;

	// GrabCut 分割算法
	cv::grabCut(
		image,				//输入图像
		result,				//分割结果图像，具有四种可能的值
		rectangle,			//包含前景的矩形
		bgModel, fgModel,	//模型
		5,					//迭代次数
		cv::GC_INIT_WITH_RECT);		//使用带边框的矩形模型

	/*	分割结果图像result，具有四种可能的值
		cv::GC_BGD：    这个值表示 明确 属于 背 景的像素（本例中矩形之外的像素），
		cv::GC_FGD：    这个值表示 明确 属于 前 景的像素（本例中没有这种像素），
		cv::GC_PR_BGD： 这个值表示 可能 属于 背 景的像素，
		cv::GC_PR_FGD： 这个值表示 可能 属于 前 景的像素（本例中矩形之内的像素的初始值）*/

	//取得标记为“可能属于前景”的像素,这个是对compare的解释
	/* if result (x,y) == cv::GC_PR_FGD(可能属于前景的像素)
			result(x,y) = 255
		else
			result(x,y) = 0;
		*/
	cv::compare(result, cv::GC_PR_FGD, result, cv::CMP_EQ);//result既是输入也是输出

#pragma region Test

	cv::namedWindow("Test");
	cv::imshow("Test", result);//掩码图像
	//这里就是自己设置了一个掩码图像
#pragma  endregion

	//创建输出图像
	cv::Mat foreground(image.size(), CV_8UC3, cv::Scalar(255, 255, 255));

	//只有前景部分被赋值（result掩码图像中像素不为0的部分），不复制背景像素
	image.copyTo(foreground, result);//result相当于掩码，255是前景，0是背景

	//显示花了矩形的输入图像
	cv::rectangle(image, rectangle, cv::Scalar(255, 255, 255), 1);
	cv::namedWindow("Image with rectangle");
	cv::imshow("Image with rectangle", image);

	//显示分割结果
	cv::namedWindow("Foreground object");
	cv:; imshow("Foreground object", foreground);

	cv::waitKey(0);
	return 0;

}	



