﻿#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>


#pragma region 用指针扫描图像,访问图像的例子
void colorReduce(cv::Mat image, int div = 64)	//在原始图像上修改，没有设置输出参数
{
	//图像行数
	int nl = image.rows;
	//每行元素数量
	int nc = image.cols * image.channels();

	for (int j = 0; j < nl; j++)		//行循环
	{
		//取得行的地址
		uchar* data = image.ptr<uchar>(j);	//ptr模板方法可以直接访问图像中一行的起始地址，相当于拿到该行元素的数组

		for (int i = 0; i < nc; i++)	//列循环
		{
			data[i] = data[i] / div * div + div / 2;	//三个通道同时被处理，因为这里nc是乘了通道数目的
			//这里是可以把指针写成数组的，data也是存储这一行元素的数组名
		}//一行结束

	}//整个图像结束
}
#pragma endregion

#pragma region 用迭代器扫描图像

void colorReduce2(cv::Mat image, int div = 64)
{
	//获取迭代器(两种方法)
	cv::Mat_<cv::Vec3b>::iterator it = image.begin<cv::Vec3b>(); //使用cv:;Mat_类获取迭代器
	cv::MatIterator_<cv::Vec3b> itend = image.end<cv::Vec3b>();	//使用cv::MatIterator_类获取迭代器

	//开始迭代器指向第一个元素，然后它开始遍历，当它遍历到终止迭代器的时候，我们认为开始迭代器和终止迭代器重合，此时迭代终止，否则的话，它就一直循环
	//注意，这里我们只有开始和终止，中间几个数我们是不确定的，也不需要知道
	//当这个指针只想一个元素，我们认为它指向了三个元素，就是三个通道的三个像素

	for (; it != itend; ++it)	//迭代器类似于一个指针，遍历整个图像
	{
		//对指针取星号，就相当于得到了相应的数组,这里我们对迭代器取星号
		(*it)[0] = (*it)[0] / div * div + div / 2;
		(*it)[1] = (*it)[1] / div * div + div / 2;
		(*it)[2] = (*it)[2] / div * div + div / 2;
	}
}
#pragma endregion

#pragma region 用at方法扫描图像

void colorReduce3(cv::Mat image, int div)
{
	int nl = image.rows;	//图像的行数
	int nc = image.cols;	//图像的列数

	for (int j = 0; j < nl; j++)
	{
		for (int i = 0; i < nc; i++)
		{
			//之前学到的，用at来访问像素值，在椒盐噪声那里
			image.at<cv::Vec3b>(j, i)[0] = image.at<cv::Vec3b>(j, i)[0] / div * div + div / 2;
			image.at<cv::Vec3b>(j, i)[1] = image.at<cv::Vec3b>(j, i)[1] / div * div + div / 2;
			image.at<cv::Vec3b>(j, i)[2] = image.at<cv::Vec3b>(j, i)[2] / div * div + div / 2;

		}//一行结束
	}
}

#pragma endregion

#pragma region 不对原图修改，输出新的图像
void colorReduceIO(const cv::Mat& image,	//输入图像，const表示图像不会在函数中修改
	cv::Mat& result,	//输出图像
	int div = 64)
{
	int nl = image.rows;	//图像行数
	int nc = image.cols;	//图像列数
	int nchannels = image.channels();	//图像通道数

	//create的特殊性，如果colorReduceIO（image,image），直接在原图上修改
	result.create(image.rows, image.cols, image.type());

	for (int j = 0; j < nl; j++)
	{
		//取得输入图像的行j的地址
		const uchar* data_in = image.ptr<uchar>(j);
		//取得输出图像的行j的地址
		uchar* data_out = result.ptr<uchar>(j);

		for (int i = 0; i < nc * nchannels; i++)
		{
			//处理每个像素
			data_out[i] = data_in[i] / div * div + div / 2;
		}
	}
}
#pragma endregion

#pragma region 用指针实现锐化
void sharpen(const cv::Mat& image, cv::Mat& result)
{
	//注意，锐化的时候我们要用到相邻位置的像素值，原来的中心像素可能作为别人的相邻像素存在
	//所以如果改变了原来中心位置的像素，再去算另一个位置的新的像素值的话，算出来是不对的
	//每一次计算，都要保证是在原始图像上计算，所以这里不能用create
	result.create(image.size(), image.type());	//结果图像的构造

	int nchannels = image.channels();	//获得通道数，这个是为了计算它每一行是一个还是三个元素
	
	//遍历所有行，除了第一行和最后一行，因为它们相邻行不全
	//用指针都是从行开始遍历的
	//for循环只能取到 行数-2 ，注意这个循环的意思
	for (int j = 1; j < image.rows - 1; j++)
	{
		const uchar* previous = image.ptr<const uchar>(j - 1);//ptr方法，直接访问图像中一行的起始位置 //上一行
		const uchar* current = image.ptr<const uchar>(j);	//当前行
		const uchar* next = image.ptr<const uchar>(j + 1);	//下一行
		//前边定义了 const，后边也要有相应的 const，这个值相当于你这个值不变了

		uchar* output = result.ptr<uchar>(j);	//输出图像的当前行，因为要修改不能定义为常量

		//遍历所有列，除第一列和最后一列，所以最后这些除去的值就没变
		//这里是从nchannels开始的，也就是跳过了第一列的通道数，后边小于是一样的
		for (int i = nchannels; i < (image.cols - 1) * nchannels; i++)
		{
			//应用锐化算法，这个函数，可以把小于0的、大于255的弄成0和255
			output[i] = cv::saturate_cast<uchar>(5 * current[i]
				- current[i - nchannels]	//left
				- current[i + nchannels]	//right
				- previous[i]				//up，这里直接对齐的，不用加减
				- next[i]);				//down
		}
	}
	//没有进行处理的第一行 最后一行  第一列 最后一列
	result.row(0).setTo(cv::Scalar(0));		//第一行
	result.row(result.rows - 1).setTo(cv::Scalar(0));	//最后一行
	result.col(0).setTo(cv::Scalar(0));		//第一列
	result.col(result.cols - 1).setTo(cv::Scalar(0));	//最后一列
}
#pragma endregion

#pragma region 用迭代器实现锐化
void sharpenIterator(const cv::Mat& image, cv::Mat& result)
{
	//这里为了方便，我们只锐化灰度图像，这里先判断是否为灰度图像
	CV_Assert(image.type() == CV_8UC1); // CV_Assert()若括号中表达式的值为false，则返回错误信息，终止程序
	
	//初始化迭代器，也就是获取迭代器
	// cv::Mat_<cv::Vec3b>::iterator it = image.begin<cv::Vec3b>(); 
	//自己写的cv::Mat_<cv::Vec3b>::iterator it = image.begin<cv::Vec3b>();
	cv::Mat_<uchar>::const_iterator it = image.begin<uchar>() + image.cols;//当前行从第二行开始
	cv::Mat_<uchar>::const_iterator itend = image.end<uchar>() - image.cols;//结束行是倒数第二行
	cv::Mat_<uchar>::const_iterator itup = image.begin<uchar>();//当前行的上一行
	cv::Mat_<uchar>::const_iterator itdown = image.begin<uchar>() + 2.0 * image.cols();//当前行的下一行，这里的begin是上一行，所以要用2乘上

	//创建输出图像
	result.create(image.size(), image.type());
	//初始化输出图像的迭代器
	cv::Mat_<uchar>::iterator itout = result.begin<uchar>() + result.cols;

	//遍历整个图像
	//迭代器是不分列的，就是说最左边一列它左边一列是第一行的最右边一列
	//所以这里遍历只是用了一个for循环，而上边那个是两个循环
	for (; it != itend; ++it, ++itout, ++itup, ++itdown)
	{
		//应用锐化算法，这里取星号就是取数组
		*itout = cv::saturate_cast<uchar>(*it * 5 - *(it - 1) - *(it + 1) - *itup - *itdown);
	}
	//未处理的值设为0，这里设置的是result图，不是image那个图，那个原图是个常量
	//迭代器不分列了，这里还要分列吗？？？？？？？？？？
	//注意这里是result.row()，不是result.rows()
	result.row(0).setTo(cv::Scalar(0));
	result.row(result.row - 1).setTo(cv::Scalar(0));
	result.col(0).setTo(cv::Scalar(0));//第一列
	result.col(result.col - 1).setTo(cv::Scalar(0));//最后一列
}
#pragma endregion


int main()
{
#pragma region 减色测试

	///<用指针扫描图像>

	//读取图像
	cv::Mat image = cv::imread("boldt.jpg");

	//处理图像
	colorReduce(image, 64);	//N = 64

	//显示图像
	//cv::namedWindow("1");
	//cv::imshow("1", image);
	//cv::waitKey(0);


	///<用迭代器扫描图像>
	
	//读取图像
	cv::Mat image2 = cv::imread("boldt.jpg");

	//处理图像
	colorReduce2(image2, 32);

	//显示图像
	//cv::namedWindow("2"); 
	//cv::imshow("2", image2);
	//cv::waitKey(0);


	///<用at方法扫描图像>
	cv::Mat image3 = cv::imread("boldt.jpg");
	colorReduce3(image3, 128);
	//cv::namedWindow("3");
	//cv::imshow("3", image3);
	//cv::waitKey(0);

	///<不对原图修改>
	cv::Mat image4 = cv::imread("boldt.jpg");
	cv::Mat image5;
	colorReduceIO(image4,image4, 64);
	//cv::namedWindow("5");
	//cv::imshow("4", image4);
	//cv::imshow("5", image4);
	cv::waitKey(0);
#pragma endregion

#pragma region 锐化图像（两个方法）
	//指针访问，这个比较快
	cv::Mat image6 = cv::imread("boldt.jpg");   //这里如果格式是 jepg的话 就会报错??
	cv::Mat result;
	sharpen(image6, result);
	cv::imshow("7", result);
	//cv::waitKey(0);

	//迭代器访问
	cv::Mat image8 = cv::imread("test.jpg",0);	//这里运行总是得不到相应的相应的图像，?????????????
	//写0，以灰度图像读入
	cv::Mat result2;
	sharpenIterator(image8, result2);
	cv::imshow("15", result2);
	cv::waitKey(0);
#pragma endregion




}



