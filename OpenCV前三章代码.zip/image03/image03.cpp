﻿#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>

int main() {
	
	// 3*3 双精度型矩阵
	cv::Matx33d matrix( 3.0, 2.0, 1.0,		//Matx那是matrix的意思
						2.0, 1.0, 3.0,
						1.0, 2.0, 3.0);
	// 3*1 向量
	cv::Matx31d vector(5.0, 1.0, 3.0);
	// 相乘
	cv::Matx31d result = matrix * vector;
	std::cout << "The result is " << result << std::endl;
	//这里最后的结果没有小数位，可能是因为 C++ 的运算符<<重载了，对数进行了一定的优化，把后边的0删去了
	// 这里 31d 就表示双精度型
	
	/*********************ROI**********************/
	cv::Mat logo;
	logo = cv::imread("smalllogo.png");

	cv::Mat image;
	image = cv::imread("puppy.bmp");

	//定义图片右下角为感兴趣区域
	cv::Mat imageROI(image,
		cv::Rect(image.cols - logo.cols,		//ROI 坐标
			image.rows - logo.rows,
			logo.cols, logo.rows));				//ROI 大小
	//logo.copyTo(imageROI);
	


	// 把标志作为掩码（必须是灰度图像）
	cv::Mat mask(logo);

	//输入标志，只复制掩码不为0的位置,说明这个logo黑色底的部分掩码为0，具体什么颜色掩码是多少，可以自己定义
	logo.copyTo(imageROI,mask);
	/******
	// 定义图片中心为感兴趣区域
	cv::Mat imageROI_2(image,
		cv::Rect(	(image.cols - logo.cols) / 2,
					(image.rows - logo.rows) / 2,
					logo.cols, logo.rows)
				);
	logo.copyTo(imageROI_2);
	


	// 使用值域来定义感兴趣区域,和区间类似
	cv::Mat imageROI;
	imageROI = image(cv::Range(0, logo.rows),
		cv::Range(0, logo.cols));
	logo.copyTo(imageROI);
	***********/

	/* 定义一些 行/列 组成的ROI
	cv::Mat imageROI = image.rowRange(start, end);
	cv::Mat imageROI = image.colRange(start, end);
	*/

	cv::imshow("Image", image);
	cv::waitKey(0);

	}