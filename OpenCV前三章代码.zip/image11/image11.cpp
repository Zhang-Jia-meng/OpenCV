﻿#include <iostream>
#include <vector>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgproc/types_c.h>

#pragma region 肤色检测函数
void detectHScolor(
	const cv::Mat& image,	//输入图像
	double minHue, double maxHue,	//色调区间
	double minSat, double maxSat,	//饱和度区间
	cv::Mat& mask)
{
	//将图像从RGB色彩空间转换到HSV色彩空间
	cv::Mat hsv;
	cv:; cvtColor(image, hsv, CV_BGR2HSV);

	//将HSV色彩空间的3个通道分割
	std::vector <cv::Mat> channels;
	cv::split(hsv, channels); //色调 饱和度 亮度

	///<筛选出色调 minHue < Hue < maxHue 的像素>

	//筛选出色调 < maxHue 的像素
	cv::Mat mask1;
	cv::threshold(channels[0], mask1, maxHue, 255, cv::THRESH_BINARY_INV);
	//筛选出色调 > minHue 的像素
	cv::Mat mask2;
	cv::threshold(channels[1], mask2, minHue, 255, cv::THRESH_BINARY);
	//合并色调掩码
	cv::Mat hueMask;
	if (minHue < maxHue)
		hueMask = mask1 & mask2;
	/*与运算，取交集*/
	else	//如果区间穿越0度中轴线
		hueMask = mask1 | mask2;
	/*并运算，有255就取255*/

	///<筛选出饱和度 minSat < Sat < maxSat 的像素>

	//筛选出饱和度 < maxSat 的像素
	cv::threshold(channels[1], mask1, maxSat, 255, cv::THRESH_BINARY_INV);
	//筛选出饱和度 > minSat 的像素
	cv::threshold(channels[1], mask2, minSat, 255, cv::THRESH_BINARY);
	//合并饱和度掩码
	cv::Mat satMask;
	satMask = mask1 & mask2;

	//组合掩码（二值图像）
	mask = hueMask & satMask;
}
#pragma endregion

int main()
{
    //读入原始图像（RGB色彩空间）
	cv::Mat image = cv::imread("boldt.jpg");
	if (!image.data) return 0;

	//显示原始图像
	cv::namedWindow("Original image");
	cv::imshow("Original image", image);

#pragma region 用色调，饱和度和亮度表示颜色
	
	//从RGB色彩空间转换成HSV色彩空间
	cv::Mat hsv;
	cv::cvtColor(image, hsv, CV_BGR2HSV);//#include <opencv2/imgproc/types_c.h>

	//把3个通道分割进3幅图像中
	std::vector<cv::Mat> channels;
	cv::split(hsv, channels);
	//channels[0],是色调H
	//channels[1],是饱和度S
	//channels[2],是亮度V

	//显示色调通道图
	cv::imshow("hue", channels[0]);
	//显示饱和度图像
	cv::imshow("saturation",channels[1]);
	//显示亮度
	cv:; imshow("value", channels[2]);

	cv::waitKey(0);
	cv::destroyWindow("value");
	cv::destroyWindow("saturation");
	cv::destroyWindow("hue");

#pragma endregion

#pragma region HSV颜色测试

	//创建一个原图像的亮度通道的副本
	cv::Mat tmp(channels[2].clone());	//保存原图像的亮度通道，后边会有一个代码修改，所以这里先留个副本以便后边再用

	///<固定亮度的图像>

	//修改原图像亮度通道内所有的像素值为255
	channels[2] = 255;
	//重新合并通道
	cv::merge(channels, hsv);
	//转回RGB色彩空间
	cv::Mat newImage;
	cv::cvtColor(hsv, newImage, CV_HSV2BGR);
	//显示结果
	cv::imshow("Fixed Value Image", newImage);

	///<固定饱和度的图像>

	//还原亮度通道
	channels[2] = tmp;
	//修改原图像饱和度通道内所有像素值为255
	channels[1] = 255;
	//重新合并通道
	cv::merge(channels, hsv);
	//转换回RGB色彩空间
	cv::cvtColor(hsv, newImage, CV_HSV2BGR);
	//显示结果
	cv::imshow("Fixed saturation", newImage);

	///<固定亮度和饱和度的图像>

	//修改原图像饱和度通道内所有像素值为255
	channels[1] = 255;
	//修改原图像亮度通道内所有像素值为255
	channels[2] = 255;
	//重新合并通道
	cv::merge(channels, hsv);
	//转换回BGR色彩空间
	cv::cvtColor(hsv, newImage, CV_HSV2BGR);
	//显示结果
	cv::imshow("Fixed saturation/value", newImage);

	cv::waitKey(0);
	cv::destroyAllWindows();
#pragma endregion

#pragma region 色彩/饱和度组合
	
	//人为生成一幅图像，用来说明这个问题
	cv::Mat hs(128, 360, CV_8UC3);

	for (int h = 0; h < 360; h++)
	{
		for (int s = 0; s < 128; s++)
		{
			hs.at<cv::Vec3b>(s, h)[0] = h / 2; //色调通道，所有色调角度
			hs.at<cv::Vec3b>(s, h)[1] = 255 - s * 2;	//饱和度通道，饱和度从高到低
			hs.at<cv::Vec3b>(s, h)[2] = 255;	//亮度通道，常数
		}
	}

	//从HSV色彩空间转换成RGB色彩空间
	cv::cvtColor(hs,newImage, CV_HSV2BGR);

	//显示图像
	cv::imshow("Hue/Saturation", newImage);
	cv::waitKey(0);

#pragma endregion

#pragma region 肤色检测

	//读入原始图像
	image = cv::imread("girl.jpg");
	if (!image.data) return 0;

	//显示原始图像
	cv::imshow("Original image", image);

	///<肤色检测>
	cv::Mat mask;

	//调用自己的肤色检测函数
	detectHScolor(
		image,	//输入图像
		160, 10,		//色调320度-20度 160 10
		25, 166,	//饱和度 0.1-0.65
		mask);		//输出的二值掩码图像
	/* 8位图像：
		色调范围 0-180度，因为OpenCV会把角度除以2，来适应单字节的存储范围
		饱和度范围：0-255度
	*/

	///<显示使用掩码后的图像>

	//创建一个黑色（灰色）3通道彩色图像
	cv::Mat detected(image.size(), CV_8UC3, cv::Scalar(0, 0, 0));
	//mask是检测到的肤色掩码，这里只复制原图像中掩码不为0的部分
	image.copyTo(detected, mask);

	//显示结果
	cv::imshow("Detection result", detected);
	cv::waitKey(0);
#pragma endregion

	return 0;
}




