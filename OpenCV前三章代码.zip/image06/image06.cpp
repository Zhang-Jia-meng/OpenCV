﻿#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>

int main()
{
	cv::Mat image1;
	cv::Mat image2;

	image1 = cv::imread("boldt.jpg");
	image2 = cv::imread("rain.jpg");

	if (!image1.data|| !image2.data)
		return 0;

	cv::imshow("1", image1);
	cv::namedWindow("2");
	cv::imshow("2", image2);
	//cv::waitKey(0);

#pragma region 图像相加
	
	cv::Mat result;
	//两图像加权相加
	cv::addWeighted(image1, 0.7, image2, 0.9, 0., result);//后边那个是偏移量
	//类似的 cv::add(),cv::subtract,cv::multiply(),cv::divide()

	cv::imshow("3", result);
	//cv::waitKey(0);

	//两图像相加，重载运算符
	cv::Mat result2;
	result2 = 0.7 * image1 + 0.9 * image2;
	cv::imshow("4", result2);
	//cv::waitKey(0);
	//cv::destroyAllWindows();
#pragma endregion

#pragma region 分割图像通道

	image2 = cv::imread("rain.jpg", cv::IMREAD_GRAYSCALE);

	//创建三幅图像的向量
	std::vector<cv::Mat> planes;	//每幅图像对应一个通道

	//把一个三通道图像分割成三个单通道图像,这里是image1，是城堡图像
	cv::split(image1, planes);

	//将下雨图像加到boldt的蓝色通道上，注意这里下雨是读入灰度的
	planes[0] += image2;

	//将三个单通道图像合并为一个三通道图像
	cv::merge(planes, result);

	cv::imshow("result", result);
	cv::waitKey(0);
#pragma endregion

}

