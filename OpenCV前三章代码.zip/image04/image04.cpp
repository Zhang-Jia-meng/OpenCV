﻿#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <random>	//这个是必须额外加的头文件

//函数：在图像中加入椒盐噪声(salt-and-pepper noise)
void salt(cv::Mat image, int n)
{
	std::default_random_engine generator;	//定义一个默认随机数生成器

	std::uniform_int_distribution<int> randomRow(0, image.rows - 1);//椒盐噪声y坐标的随机数范围
	std::uniform_int_distribution<int> randomCol(0, image.cols - 1);//椒盐噪声x坐标的随机数范围

	int i, j;
	for (int k = 0; k < n; k++) //生成n个椒盐噪声
	{
		//随机生成图形位置，将随机数生成器对象传给随机数范围对象
		i = randomCol(generator);//椒盐噪声的x坐标
		j = randomRow(generator);//椒盐噪声的y坐标

		if (image.type() == CV_8UC1)	//如果是灰度图像
		{
			image.at<uchar>(j, i) = 255;	//这是一种访问像素的方式
											//将颜色替换成白色，增加椒盐噪声
		}
		else if (image.type() == CV_8UC3)
		{
			//方式一
			//Vec3b:含三个无符号字符类型的数据 Vec<uchar，3>
			image.at<cv::Vec3b>(j, i)[0] = 255; //B
			image.at<cv::Vec3b>(j, i)[1] = 255; //G
			image.at<cv::Vec3b>(j, i)[2] = 255; //R
			//方式二
			//直接使用短向量
			//image.at<cv::Vec3b>(j, i) = cv::Vec3b(255, 255, 255);
		}
	}
}

//函数salt2，只对灰度图像起作用
void salt2(cv::Mat image, int n)
{
	//必须是灰度图像
	CV_Assert(image.type() == CV_8UC1);

	//默认随机数生成器
	std::default_random_engine generator;
	std::uniform_int_distribution<int> randomRow(0, image.rows - 1);
	std::uniform_int_distribution<int> randomCol(0, image.cols - 1);

	//用Mat_模板来操作图像 cv:;Mat -> cv::Mat_
	cv::Mat_<uchar>img(image);//将cv::Mat_类的对象img初始化为图像image，数据类型是uchar
	//另一种转换方法
	cv::Mat_<uchar>& im2 = reinterpret_cast<cv::Mat_<uchar>&>(image);

	
	int i, j;
	for (int k = 0; k < n; k++)
	{
		//随机生成图形位置
		i = randomCol(generator);
		j = randomRow(generator);

		img(j, i) = 255;
	}
}


int main()
{/*
#pragma region 用cv::Mat访问图像
	//读取图像
	cv::Mat image = cv::imread("boldt.jpg", cv::IMREAD_COLOR);

	//调用函数以添加噪声
	salt(image, 3000);	//白色的像素（噪声），3000个
	
	//显示图像
	cv::namedWindow("output");
	cv::imshow("output", image);
	cv::waitKey(0);
#pragma endregion
*/
#pragma region 用cv::Mat_操作图像

	//读取图像
	cv::Mat image2 = cv::imread("boldt.jpg", cv::IMREAD_GRAYSCALE); //注意这里只能是读取灰度的，不能照搬上边的代码

	//调用函数以添加噪声
	salt2(image2, 20);	//白色的像素（噪声），20个
	
	//显示图像
	cv::namedWindow("output2");
	cv::imshow("output2", image2);
	cv::waitKey(0);
#pragma endregion

}
