﻿#include <opencv2/highgui.hpp>
#include "colordetector.h"



int main()
{
#pragma region 用策略设计模式比较颜色
	///<探测出图像中与目标颜色相近的颜色>

	//1.创建图像处理器对象
	ColorDetector cdetect;

	//2.读取输入的图像
	cv::Mat image = cv::imread("boldt.jpg");
	if (image.empty())return 0;
	cv::namedWindow("Original Image");
	cv::imshow("Original Image", image);

	//3.设置输入参数，在这里就是设置了你要取的那个颜色，目标颜色
	cdetect.setTargetColor(230, 190, 130);//这里的颜色(B=230,G=190,R=130),表示蓝天的颜色

	//4.处理图像，这是算法的主要处理过程就在这，就是给你找相近的颜色。
	cv::Mat result = cdetect.process(image);//探测相近颜色

	//5.显示结果
	cv::namedWindow("result");
	cv::imshow("result", result);//白色像素表示检测到指定颜色，黑色表示未检测到
	cv::waitKey(0);

#pragma endregion

#pragma region 使用CIE L*a*b色彩空间

	//这里颜色的距离计算使用CIE L*a*b色彩空间
	ColorDetector colordetector(
		230, 190, 130		//要探测的目标颜色
		45,				//允许的最大差距
		true);			//使用CIE色彩空间

	//处理图像并显示二值结果
	result = colordetector(image);		//调用仿函数
#pragma endregion

#pragma region floodfill函数,漫水填充算法

	/*从起始点开始填充一个连接域，连通性由像素值的接近程度来衡量*/

	//测试floodfill函数
	cv::floodFill(
		image,					//输入/输出图像，在原图上进行探测和修改
		cv::Point(100, 50),		//起始点/种子点（天空的位置），这里设置的不是像素，是坐标
		cv::Scalar(255, 255, 255),	//填充颜色，颜色相近的话填充为白色
		(cv::Rect*)0,				//填充区域的边界矩形，这里设置为无边界
		cv::Scalar(35, 35, 35),		//最大下行，也就是 起始像素 - 差值 < 探测像素
		cv::Scalar(35, 35, 35),		//最大上行，也就是 探测像素 < 起始像素 + 差值
		cv::FLOODFILL_FIXED_RANGE);	//固定范围模式，也就是所有点像素与起始点像素比较
		//浮动模式的话，就是符合的点我标注，下一次我再找的话，这个点就成了我新的起始点

	//显示结果
	cv::namedWindow("Flood Fill result");
	cv::imshow("Flood Fill result", image);
	cv::waitKey(0);

#pragma endregion

	return 0;

}


	




