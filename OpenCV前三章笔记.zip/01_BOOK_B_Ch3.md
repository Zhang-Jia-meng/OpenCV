### OpenCV 数据类型 PDF P39-42
* 基础数据类型：<br> 直接从C++中继承的，比如 int 和 float 等;
* 辅助对象：<br>
比如垃圾收集指针类、用于数据切片的范围对象、抽象的终止条件类等;
* 大型数组类型：<br>
专门针对图片操作的一类；<br><br>
*STL：标准模板库*

### 基础数据类型
#### 固定向量类 cv::Vec <>
#### 介绍
模板类，原语的容器类，也就是说可以看成是C++原来数据类型的一个容器，也叫**固定向量类**。<br>
我们现在把它看做是一个处理**小型向量**的类，编译前维度是已知的。
#### 使用
* 大部分时候我们不是直接写cv::Vec <>，我们是写它的别名（typedef），比如：**cv::Vec2i**,  **cv::Vec3i**, **cv::Vec4d**.在这里2i就表示2个元素的整型向量，其他类推。
* 任何有着 cv::Vec{2,3,4,6}{b,w,s,i,f,d}形式的声明，对于2-6个维度的6种数据类型的任何组合都是有效的。
    * b = unsigned char.
    * w = unsigned short.
    * s = short.
    * i = int.
    * f = float. (32位浮点大小)
    * d = double.
    
#### 固定矩阵类 cv::Matx <>
* 与上边的固定向量类一样，编译前维度已知，和cv::Mat不是一个东西。<br>
* 格式：cv::Matx{1,2,3,4,6}{1,2,3,4,6}{f,d},需要注意，笔记里的代码有时候为了方便看写成了中文，不要全粘贴。

#### cv::Point类
* 与固定向量类类似，只是访问的时候通过名称变量访问，比如**mypoint.x** , **mypoint.y**等
* 格式：**cv::Point2f**，**cv::Point2i**等，与上边类似。
-  **直接受Point支持的操作**      
    - 默认构造函数  cv::Point2i p;  cv::Point3i p;
    - 复制构造函数 cv::Point3f p2(p1);
    - 值构造函数 cv::Point2i (x0.x1);  cv::Point3d p(x0,x1,x2);
    - 构造成固定向量类   (cv::Vec3f) p;
    - 成员访问 p.x,p.y (p.z)
    - 点乘 float x = p1.dot(p2);
    - 双精度点乘  double x = p1.dot(p2);
    - 叉乘,**只针对三维向量**  p1.cross(p2);
    - 判断一个点p是否在举行r内,**只针对二维向量** p.inside(r);


#### cv::Scalar类
* 本质上是一个四维Point类，一般是双精度四元素向量，它和上边固定向量类都是通过**下标**访问的。
- **cv::Scalar类支持的操作**
    * 默认构造函数 cv::Scalar s;
    * 复制构造函数 cv::Scalar s2(s1);
    * 值构造函数 cv::Scalar s(x0); cv::Scalar s(x0,x1,x2,x3);
    * 元素相乘 s1.mul(s2);
    * (四元数)共轭 s.conj(); // return cv::Scalar(s0,-s1,-s2,-s2);   ???？？？？
    * (四元数)真值测试 s.isReal();   //return true,if s1 等于 s2 等于 s3 等于 0？？？？
    

#### cv::Size、cv::Rect类
* cv::Size有**width**和**height**两个属性，而不是x和y；默认是整数型的2i，相当于 cv::Size 等价于 cv::Size2i.可以写**cv::Size2f**.
- **size类直接支持的操作**
    * 默认构造函数 cv::Size sz; cv::Size2i sz; cv::Size2f sz;
    * 复制构造函数 cv::Size sz2(sz1);
    * 值构造函数 cv::Size2f sz(w,h);
    * 成员访问 sz.width;sz.height;
    * 计算面积 sz.area();
    
* cv::Rect有 width height x y 四个属性；默认也是整数类型；
* cv::RotateRect 表示非轴对称矩形，含有cv::Point2f类型的**中心点**，一个cv::Size2f类型的**size**，还有一个额外的浮点类型的**角度**。
* cv::Rect 直接支持的操作
    * 默认构造函数 cv::Rect r;
    * 复制构造函数 cv::Rect r2(r1);
    * 值构造函数 cv::Rect(x,y,w,h);
    * 由起始点和大小构造  cv::Rect(p,sz);
    * 有两个对角构造 cv::Rect(p1,p2);
    * 成员访问 r.x; r.y; r.width; r.height;
    * 计算面积 r.area();
    * 提取左上角 r.tl();
    * 提取右下角 r.br();
    * 判断点p是否在矩阵r内 r.contains(p); 
    
* cv::Rect 对象的覆写操作符
    * 矩形r1和矩形r2的交集 cv:：Rect r3 = r1&r2; r1&=r2;
    * 同时包含矩形r1和矩形r2的最小面积矩形 cv::Rect r3 = r1|r2; r1|=r2;
    * 平移矩形r x个数量 cv::Rect rx = r+x; r += x;
    * 扩大矩形r s个大小 cv::rect rs = r+s; r += s;
    * 比较矩形r1与矩形r2是否相等 bool eq = (r1==r2);
    * 比较矩形r1和矩形r2是否不想打 bool ne = (r1!=r2);