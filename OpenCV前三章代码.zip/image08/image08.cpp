﻿#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

int main()
{
	//单通道数组
	cv::Mat m1 = cv::Mat::eye(10, 10, CV_32FC1);

	printf(
		"Element (3,3) is %f\n", m1.at<float>(3, 3)//??????????????//1.0000
	);
	//多通道数组
	cv::Mat n = cv::Mat::eye(10, 10, CV_32FC2);

	printf(
		"Element (3,3) is (%f,%f)\n", n.at<cv::Vec2f>(3, 3)[0], n.at<cv::Vec2f>(3, 3)[1]
	);

	/*//访问复数数组，版本有些出入
	cv::Mat l = cv::Mat::eye(10, 10, cv::DataType<cv::Complexf>::type);//版本问题

	printf("Element (3,3) is %f + i%f\n", m.at<cv::Complexf>(3, 3).re,
		m.at<cv::Complexf>(3, 3).im);
	*/	

	//计算三通道三维数组最长元素
	int sz[3] = { 4,4,4 };
	cv::Mat m(3, sz, CV_32FC3);//3维，大小4*4*4
	cv::randu(m, -1.0f, 1.0f);//用随机数填充

	float max = 0.0f;
	cv::MatConstIterator_<cv::Vec3f> it = m.begin<cv::Vec3f>();
	while ( it != m.end<cv::Vec3f>()) {
		int len2 = (*it)[0] * (*it)[0] + (*it)[1] * (*it)[1] + (*it)[2] * (*it)[2];
		if (len2 > max)
			max = len2;
		it++;
	}
	printf("The max is %f\n", max);
}


