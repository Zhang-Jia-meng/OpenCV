﻿#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>		//网上找的头文件

//测试函数，它创建一幅图像
cv::Mat function() {
	cv::Mat ima(500, 500, CV_8U, 50);		//创建图像
	//cv::Mat ima(500, 500, CV_8U, cv::Scalar(50));		创建图像,两个方法一致，这个函数其实可以放四个值
	return ima;								//返回图像
}

int main() {
	//创建一个240行*320列的图像
	cv::Mat image1(240, 320, CV_8U, 100);	//CV_8U 表示每个像素对应1字节（灰度图像），U表示无符号，S表示有符号
	cv::imshow("Image", image1);
	cv::waitKey(0);							//这里有个等待，所以刚才运行的时候，是一幅图、一幅图地出来

	//重新分配一个新图像
	/*****  create      
	分配或重新分配图像的数据块，其实就是换一下像素的值。如果图像已经被分配，原来的内容
	会被先释放，如果新分配的和原来的尺寸一样的话，就不会重新分配内存了，只改变像素的值
	*******/
	image1.create(200, 200, CV_8U);
	image1 = 200;							//这里是上边重新分配大小，下边这句是分配像素值

	cv::imshow("Image", image1);
	cv::waitKey(0);

	//创建一个红色图像
	//通道次序 BGR，所以是红色是满的
	cv::Mat image2(240, 320, CV_8UC3, cv::Scalar(0, 0, 255));	//CV_8UC3 C3表示三个通道（彩色图像）
	
	/*****  cv::Scalar 
	一个简单的数据结构，用于在调用函数时传递像素值，通常包含一个值或者三个值，上边这个就是三个值，表示是用红色初始化
	同理，初始化灰度图像可以写 cv::Scalar(100);
	*******/

	//或者
	//cv::Mat image2(cv::Size(320, 240), CV_8UC3);
	//上边的 cv::Size 访问的就是图像的尺寸大小
	//image2 = cv::Scalar(0, 0, 255);  这个和那个等于200一样吗？？？

	cv::imshow("Image", image2);
	cv::waitKey(0);


	//读入一幅图像
	cv::Mat image3 = cv::imread("puppy.bmp");



	//所有这些图像都指向同一个数据块,下边的两种拷贝方式都是浅拷贝
	/*	赋值操作：只是拷贝了头部，没有拷贝数据块，所以指向的是一个数据块	*/
	cv::Mat image4(image3);
	image1=image3;				// image3 是最原始的图像



	//这些图像是源图像的副本图像
	/*	这里的拷贝是深拷贝，头部和数据块都拷贝了，各有各的数据块，各指向各的数据块	*/
	image3.copyTo(image2);
	cv::Mat image5 = image3.clone();

	//转换图像进行测试，转换一下看哪些是真复制，哪些是假复制
	cv::flip(image3, image3, 1);

	//检查哪些图像在处理过程中受到了影响
	cv::imshow("Image3", image3);
	cv::imshow("Image1", image1);		//浅拷贝，变
	cv::imshow("Image2", image2);		//深拷贝，不变
	cv::imshow("Image4", image4);		//浅拷贝，变
	cv::imshow("Image5", image5);		//深拷贝，不变
	cv::waitKey(0);

	//从函数中获取一个灰度图像，调用了上边的测试函数
	cv::Mat gray = function();

	cv::imshow("Image", gray);
	cv::waitKey(0);

	//作为灰度图像读入
	image1 = cv::imread("puppy.bmp", cv::ImreadModes::IMREAD_GRAYSCALE);
	image1.convertTo(image2, CV_32F, 1/255.0 , 0.0);
	/********  convertTo 
	用来对不同数据类型的图像进行转换，这里有两个参数：
	缩放比例 和 偏移量 
	注意 ：这里的转换必须保证两个图片的通道数量相同 
	***********/
	cv::imshow("Image2", image2);
	cv::imshow("Image1", image1);
	std::cout << "This image2 is " << image2.rows << "*" << image2.cols << std::endl;
	std::cout << "This image1 is " << image1.rows << "*" << image1.cols << std::endl;
	cv::waitKey(0);
	//上述输出不是浮点型，本来即不是浮点型
	//注意，转换图像转换的是像素，不是转换你的列和行
	//缩放比例是乘除 相应的数，偏移量是 在后边 加减 ，比如原像素是 A，两个参数分别是α和 β，那最后结果及时 α*A + β
	return 0;

}