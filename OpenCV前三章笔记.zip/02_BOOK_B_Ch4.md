### 访问数组元素    PDF P69-
#### 直接访问
```
//访问单通道数组
cv::Mat m = cv::Mat::eye(10,10,CV_32FC1);

printf("Element (3,3) is %f\n",m.at<float>(3,3));

//访问多通道数组
cv::Mat n = cv::Mat::eye(10,10,CV_32FC2)；

printf("Element (3,3) is (%f,%f)\n",m.at<cv::Vec2f>(3,3)[0],m.at<cv::Vec2f>(3,3)[1]);
//注意，访问多通道数组时，中间<float>就变为<cv::Vec2f>了

//另外，在开始创建的时候，cv::Mat::eye()和cv::Mat::ones()都是只有第一通道会设置为1，其他通道是0.
// 不要写成 cv::Mat eye(),中间还有两个冒号。

//访问复数数组
cv::Mat l = cv::Mat::eye(10,10,cv::DataType<cv::Complexf>::type);

printf("Element (3,3) is %f + i%f\n",m.at<cv::Complexf>(3,3).re,m.at<cv::Complexf>(3,3).im);


//at<>()访问器函数的变体

M.at<int>(i);   //整型数组M中的元素i
M.at<float>(i,j);   // 浮点型数组M中的元素(i,j);
M.at<int>(pt);  //整型矩阵M中处于(pt.x,pt.y)的元素
M.at<float>(i,j,k); //三维浮点型矩阵M中处于(i,j,k)未知的元素
M.at<uchar>(idx);   //无符号字符数组M中处于idx[]所索引的n维位置的元素
```
#### ptr<>()
数组中的数据是按行连续组织的，我们可以用该成员函数访问二维数组的一个指定的行。<br><br>
它是模板函数，需要一个类型名进行实例化。<br><br>
函数接收：一个整形参数来指示希望指针指向的行。<br><br>
函数返回：一个和矩阵原始数据类型相同的数据指针，比如数组类型是 CV_32FC3,返回 float*。<br><br>
给定一个类型为 float 三通道的矩阵 mtx，结构体 mtx.ptr\<Vec3f\>(3)将返回mtx的**第三行**指向第一个元素第一个浮点通道的指针。<br><br>
迭代器要比 at 和指针访问都慢，OpenCV内置函数要比循坏快。
#### 行连续
如果要访问一个数组中的所有东西，可能需要一次性迭代一行，因为这些行在数组中有可能是连续的。<br><br>
但是也有可能不连续，成员函数 isContinuous()可以告诉我们数组是否被连续的打包。<br><br>
如果数组被连续打包，我们既可以通过获取它第一行第一个元素指针，然后便利整个数组，仿佛是一个一维数组。
#### 迭代器
cv::MatConstIterator<> :用于只读数组<br><br>
cv::MatIterator<> :用于非只读数组<br><br>
cv::Mat 的成员函数 begin() 和 end() 会返回上述类型的对象<br><br>
所有迭代器都必须在数组建立的时候声明并指定一个对象类型。<br><br>
```
//  image08
int sz[3] = { 4,4,4 };
	cv::Mat m(3, sz, CV_32FC3);//3维，大小4*4*4
	cv::randu(m, -1.0f, 1.0f);//用随机数填充

	float max = 0.0f;
	cv::MatConstIterator_<cv::Vec3f> it = m.begin<cv::Vec3f>();
	while ( it != m.end<cv::Vec3f>()) {
		int len2 = (*it)[0] * (*it)[0] + (*it)[1] * (*it)[1] + (*it)[2] * (*it)[2];
		if (len2 > max)
			max = len2;
		it++;
	}
	printf("The max is %f\n", max);
```
### 数组迭代器NAryMatIterator
cv::NaryMatIterator<br><br> 该迭代器只要求被迭代的数组有相同的几何结构（维度以及每一个维度的范围）<br><br>
该迭代器会返回一堆数组来进行 N-ary 迭代器操作，这些返回的数组也称为 面 plane。<br><br>
一个面表示输入数组有连续内存的部分，也就是说它把一个不连续的分成了好多个连续的部分。<br><br>
面并不是局限在一维二维，它可以更大，只要内存是连续的。

### 通过块访问数组元素
```
m.row(i);   //m中第i行数组
m.col(j);   //m中第j列数组
//上边两种方法是，把一个整形变量i，j作为参数，
//返回这个变量所索引的行或者列。

m2 = m.row(3);
//这个表达式会创建一个新的数组头，并分配data指针、step数组以及其他东西，这样它将可以访问m中第三行数据。

m.rowRange(i0,i1);
m.rowRange(cv::Range(i0,i1));
m.colRange(j0,j1);
m.colRange(cv::Range(j0,j1));
//这种方法得到的不只是一行一列，是多行多列
//这个范围是i0 / j0 到 i1-1 / j1-1，就是最后那个索引不包括

m.diag(d);
//m中偏移为d的对角线所组成的数组
//如果 d=0,就返回主对角元素
//如果输入正数，向上半部分偏移相应距离然后返回对角元素，负数向下半部分平移。

m(cv::Range(i0,i1),cv::Range(j0,j1));
//m中从点(i0，j0)到点(i1-1,j1-1)所包含的数据构成的数组

m(cv::Rect(i0,i1,w,h));
//m中从点(i0,j0)到点(i0+w-1,j0+h-1)所包含的数据构成的数组

m(ranges);
//m中依据ranges[0]到range[ndim-1]所索引区域构成的数组
```
### 矩阵表达式：代数和cv::Mat
```
m0 + m1,m0 - m1;//矩阵加减法

m0 + s; m0 - s; s+m0; s-m1;//矩阵和单个元素的加减

-m0;//矩阵取负

s*m0; m0*s;//矩阵按单元素缩放

m0.mul(m1); mo/m1;//按元素将 m0 和 m1 相乘/相除；

mo*m1;//矩阵乘法

m0.inv(method);//对矩阵求逆,默认是DECONP_LU
//cv::DECOMP_LU 对任意非奇异矩阵都有效
//cv::DECOMP_CHOLESKY 只在矩阵半正定时有效
//cv::DECOMP_SVD 矩阵奇异或者非方阵都可，可求伪逆。

m0.t();//对矩阵求转置

m0>m1;m0>=m1;m0==m1;m0<=m1;m0<m1;
//按元素进行比较，返回元素只有0和255的ucha类型矩阵

m0&m1; m0|m1; m0^m1; ~m0;
m0&s; s&m0; m0|s; s|m0; m0^s; s^m0;
//矩阵和矩阵或者矩阵和单个元素按位进行逻辑操作

min(m0,m1); max(m0,m1); min(m0,s);
min(s,m0); max(m0,s); max(s,m0);
//矩阵和矩阵或者矩阵和单个元素按元素取最大值、最小值

cv::abs(m0);//对m0按元素取绝对值

m0.cross(m1); m0.dot(m1);//向量叉乘和点乘，叉乘只能三维的

cv::Mat::eye(Nr,Nc,type);
cv::Mat::zeros(Nr,Nc,type);
cv::Mat::ones(Nr,Nc,type);
//可返回规定类型的N*N矩阵
```
### 饱和转换
```
uchar&Vxy = m0.at<uchar>(y,x);
Vxy = cv::saturate_cast<uchar>((Vxy-128)*2 + 128);
//如果不在无符号整型范围内，这个函数会自己弄成0或者255
//先将一个8位元素的引用赋值给变量Vxy？？？？？？？？
```
### 数组可做的其他事情
参考图示笔记：表4-9